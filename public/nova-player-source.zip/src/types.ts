export type AudioFormat = 'mp3' | 'wav' | 'flac' | 'aac' | 'ogg' | 'm4a';

export interface LyricLine {
  time: number; // in seconds
  text: string;
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  format: AudioFormat;
  coverArt: string; // URL or CSS gradient or data URI
  file?: File;
  synthPreset?: string; // For built-in high quality procedural synthesis
  audioUrl?: string;
  lyrics?: LyricLine[];
  folder: string;
  genre: string;
  year?: number;
  bitRate?: string;
  playCount: number;
  lastPlayed?: number; // timestamp
  isFavorite: boolean;
  isHidden?: boolean;
  isFeatured?: boolean;
  hasCustomMetadata?: boolean;
  isDownloaded?: boolean;
  dateAdded: number; // timestamp
}

export interface Playlist {
  id: string;
  name: string;
  description: string;
  coverArt: string;
  trackIds: string[];
  isBuiltIn?: boolean;
  createdAt: number;
  updatedAt: number;
}

export type EQPreset = 
  | 'Normal' 
  | 'Bass Boost' 
  | 'Rock' 
  | 'Pop' 
  | 'Jazz' 
  | 'Classical' 
  | 'EDM' 
  | 'Vocal' 
  | 'Custom';

export interface ClarityEngineState {
  enabled: boolean;
  ultraAirHz: number; // 0 to 100% (20,000Hz ultra-high air harmonic restoration)
  vocalTransparency: number; // 0 to 100% (anti-mud vocal clarity filter)
  analogWarmth: number; // 0 to 100% (tube analog silk & even harmonics)
  transientSnap: number; // 0 to 100% (crisp acoustic pluck & drum attack)
  hiResUpsampling: boolean; // 96kHz / 24-bit studio oversampling
}

export interface EqualizerState {
  enabled: boolean;
  preset: EQPreset;
  bands: number[]; // 5, 10, or 12 band gains (-12dB to +12dB)
  bandMode: '5-band' | '10-band' | '12-band';
  bassBoost: number; // 0 to 100
  reverb: number; // 0 to 100
  stereoWidening: number; // 0 to 100
  dolbyAtmos: boolean;
  dolbyProfile?: 'cinema' | 'music' | 'vocal'; // Dolby soundstage profile
  dolbyDialogueClarity?: number; // 0 to 100
  eightDAudio: boolean; // Dynamic 360° / 8D spatial binaural audio effect
  eightDSpeed?: 'slow' | 'medium' | 'fast';
  eightDDistance?: 'near' | 'medium' | 'far';
  eightDMode?: 'orbit' | 'pendulum';
  clarityEngine?: ClarityEngineState; // NOVA CrystalClear™ Ultra-Hz Engine
}

export type IEMTargetCurve = 
  | 'harman-in-ear'     // Harman In-Ear Target 2019 (Audiophile Gold Standard)
  | 'dynamic-slam'      // Dynamic Driver Punch & Warmth (Tactile Kick)
  | 'balanced-armature' // Multi-BA / Knowles Vocal Intimacy & Micro-Detail
  | 'planar-speed'      // Planar Magnetic Ultrawide Separation & Speed
  | 'crinacle-neutral'  // Crinacle IEF Neutral Studio Monitor
  | 'fun-v-shaped';     // V-Shaped Bass & High Energy

export interface IEMSoundStageState {
  enabled: boolean;
  targetCurve: IEMTargetCurve;
  crossfeed: 'off' | 'subtle' | 'studio' | 'holographic'; // Binaural Out-of-Head Soundstage
  subBassRumble: number; // 0 to 100% (In-Ear Acoustic Seal 35-55Hz boost)
  trebleAir: number; // 0 to 100% (16kHz harmonic air shimmer)
  driverImpedance: 'high-sensitivity' | 'standard' | 'high-drive'; // 16Ω, 32Ω, High Gain
}

export type ShuffleMode = 'off' | 'all';
export type RepeatMode = 'off' | 'all' | 'one';
export type SortOption = 'title' | 'dateAdded' | 'duration' | 'artist';
export type SortDirection = 'asc' | 'desc';

export type LibrarySubTab = 'songs' | 'albums' | 'artists' | 'genres' | 'folders' | 'playlists' | 'downloaded';
export type MainTab = 'home' | 'library' | 'cloud' | 'search' | 'manager' | 'settings';

export type TelegramChannelConfig = {
  botToken: string;
  channelId: string;
  channelTitle: string;
  isConfigured: boolean;
  lastSyncTime?: number;
};

export type AudioStreamingQuality = 'data-saver' | 'standard' | 'high-res' | 'lossless';

export interface SettingsState {
  theme: 'amoled' | 'dark' | 'midnight' | 'slate' | 'light' | 'light-silver' | 'warm-light' | 'color-emerald' | 'color-violet' | 'color-sunset' | 'color-cyan';
  accentColor: string;
  streamingQuality: AudioStreamingQuality; // Audio Quality: Data Saver (128k), Standard (192k), High-Res (320k), Lossless FLAC
  crossfadeSecs: number;
  gapless: boolean;
  highQuality: boolean;
  supportedFormats: AudioFormat[];
  scanFolders: string[];
  autoScanOnStartup: boolean;
  // User Customizations
  showLiveEvent: boolean; // Toggle Live Event Poster and visualizer on/off
  soundAliveSpectrum: boolean; // Sound live spectrum toggle (default: false)
  showTopStatusBar: boolean; // Show top status bar toggle
  topBarRedAccent: boolean; // Show Lock, Time, EQ, Panel in sleek red word style
  homeShowResumeCard: boolean; // Home screen hero card
  homeShowRecent: boolean; // Home screen recently played
  homeShowMostPlayed: boolean; // Home screen most played
  libraryDefaultSubTab: LibrarySubTab; // Default library sub-tab
  libraryViewMode: 'list' | 'grid'; // Grid vs List for albums & artists
  libraryShowCharacterGrid: boolean; // Show Music Character/Mood shelf in library
  searchInstantFilter: boolean; // Instant live search
  searchShowUnheardShelf: boolean; // Show never-heard-before tracks shelf in search
  systemNotificationsEnabled: boolean; // System Notification & media session
  transitionDelaySecs: number; // Delay between songs in seconds (0 = instant, 0.5s, 1s, 2s, 3s, etc.)
  autoAdvanceLoop: boolean; // Loop back to start when queue finishes so playback never stops

  // BitChord-Inspired & Customizable Shelves
  homeShelves: {
    showRecentlyPlayed: boolean;
    showQuickPicks: boolean;
    showMoodTherapy: boolean;
    showArtistSpotlight: boolean;
    showAlbumsSingles: boolean;
    showAllTracks: boolean;
    cardStyle: 'portrait' | 'square' | 'compact';
  };
  nowPlayingConfig: {
    layoutStyle: 'immersive-backdrop' | 'curved-card' | 'vinyl-disc';
    showLyricsLine: boolean;
    showVolumeBar: boolean;
    infiniteAutoplay: boolean;
  };
}
